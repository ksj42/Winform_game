﻿/*
 * 2021-04-08
 * 현재진행:게임에서의 2번 선택까지 만들었다. 
 * 다음진행: 3번,4번,, 진행시 확인해야한다.
 * 
*/









using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{

    public partial class Form1 : Form
    {
        Button[] btn = new Button[36];
        Button btn2 = new Button();
        static int num = 6;
        static int margin = 10;
        static int btnWidth = 80;
        static int btnHeight = 80;
        static int N = num;
        static int i;
        static int j;
        

        public Form1()
        {
            InitializeComponent();

            this.Width = 2 * margin + num * btnWidth + 40 * 3 + 2 * num;//창 가로 크기
            this.Height = 2 * margin + num * btnWidth + 2 * 2 + 2 * num + 24;

            btn2 = new Button();
            btn2.Text = "초기화";
            btn2.Size = new Size(btnWidth, btnHeight-20);
            btn2.Location = new Point(515,10);
            btn2.Click += Form1_Click;
            Controls.Add(btn2);

            for (int i = 0; i < btn.Length; i++)
            {
                btn[i] = new Button();
                btn[i].Text = (i + 1).ToString();
                btn[i].Size = new Size(btnWidth, btnHeight);
                btn[i].Location = new Point(margin + i % 6 * btn[i].Width, margin + i / 6 * btn[i].Height);
                btn[i].Click += Form1_Click;
                Controls.Add(btn[i]);
            }

            int j;
            double mid = 0;
            //int N = num;
            char[,] room = new char[N, N];
            for (int i = 0; i < N; i++)
            {
                for (j = 0; j < N; j++)
                {

                    mid = Math.Sqrt(Math.Pow(i, 2) + Math.Pow(j, 2));
                    if (N - 1 <= mid && mid < N)
                    {
                        room[i, j] = 'b';
                    }
                    else
                    {
                        room[i, j] = 'w';
                    }
                }
            }
            int numb = 0;

            for (int i = N-1; i >= 0; i--)
            {
                for (j = 0; j < N; j++)
                {
                    if (room[i, j] == 'b')
                    {
                        btn[numb].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[numb].BackColor = SystemColors.Control;
                    }
                    numb++;
                }
            }
        }//Form()

     

        private bool Check()
        {

            //btn[0].Text = "hi";

            int i;
            for (i=0; i<36; i++)
            {
                if (btn[i].BackColor != SystemColors.Control)
                {
                    return false;
                }
            }

            return true;
        }

        int click_count = 0;
        private void Form1_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            click_count++;
            Temp(btn.Text);
            
            label1.Text = click_count.ToString();
            //check_sol(btn.Text);
            //MessageBox.Show(btn2.Text + "번 버튼이 클릭되었습니다.");
        }
        
        private void Temp(string c)
        {




            if (c=="초기화")
            {
                int j;
                double mid = 0;
                click_count = 0;
                //int N = num;
                char[,] room = new char[N, N];
                for (int i = 0; i < N; i++)
                {
                    for (j = 0; j < N; j++)
                    {

                        mid = Math.Sqrt(Math.Pow(i, 2) + Math.Pow(j, 2));
                        if (N - 1 <= mid && mid < N)
                        {
                            room[i, j] = 'b';
                        }
                        else
                        {
                            room[i, j] = 'w';
                        }
                    }
                }
                int numb = 0;

                for (int i = N - 1; i >= 0; i--)
                {
                    for (j = 0; j < N; j++)
                    {
                        if (room[i, j] == 'b')
                        {
                            btn[numb].BackColor = Color.SkyBlue;
                        }
                        else
                        {
                            btn[numb].BackColor = SystemColors.Control;
                        }
                        numb++;
                    }
                }
            }

            if (c == "1")
            {
                int k;
                for (k=0;k<6 ;k++ )
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }
                
                for(k=6;k<36 ;k=k+6 )
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }
            }


            if (c == "2")
            {
                int k;
                for (k = 0; k < 6; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 6+1; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }
            }


            if (c == "3")
            {
                int k;
                for (k = 0; k < 6; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 6 + 2; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }
            }

            if (c == "4")
            {
                int k;
                for (k = 0; k < 6; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 6 + 3; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }
            }

            if (c == "5")
            {
                int k;
                for (k = 0; k < 6; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 6 + 4; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }
            }
            if (c == "6")
            {
                int k;
                for (k = 0; k < 6; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 6 + 5; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }
            }


            if (c == "7")
            {
                int k;
                for (k = 6; k < 12; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[6].BackColor == SystemColors.Control)
                {
                    btn[6].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[6].BackColor = SystemColors.Control;
                }
            }


            if (c == "8")
            {
                int k;
                for (k = 6; k < 12; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0+1; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[7].BackColor == SystemColors.Control)
                {
                    btn[7].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[7].BackColor = SystemColors.Control;
                }
            }


            if (c == "9")
            {
                int k;
                for (k = 6; k < 12; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 2; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[8].BackColor == SystemColors.Control)
                {
                    btn[8].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[8].BackColor = SystemColors.Control;
                }
            }


            if (c == "10")
            {
                int k;
                for (k = 6; k < 12; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 3; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[9].BackColor == SystemColors.Control)
                {
                    btn[9].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[9].BackColor = SystemColors.Control;
                }
            }

            if (c == "11")
            {
                int k;
                for (k = 6; k < 12; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 4; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[10].BackColor == SystemColors.Control)
                {
                    btn[10].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[10].BackColor = SystemColors.Control;
                }
            }

            if (c == "12")
            {
                int k;
                for (k = 6; k < 12; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 5; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[11].BackColor == SystemColors.Control)
                {
                    btn[11].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[11].BackColor = SystemColors.Control;
                }
            }


            if (c == "13")
            {
                int k;
                for (k = 12; k < 18; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 ; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[12].BackColor == SystemColors.Control)
                {
                    btn[12].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[12].BackColor = SystemColors.Control;
                }
            }

            if (c == "14")
            {
                int k;
                for (k = 12; k < 18; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0+1; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[13].BackColor == SystemColors.Control)
                {
                    btn[13].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[13].BackColor = SystemColors.Control;
                }
            }

            if (c == "15")
            {
                int k;
                for (k = 12; k < 18; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 2; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[14].BackColor == SystemColors.Control)
                {
                    btn[14].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[14].BackColor = SystemColors.Control;
                }
            }


            if (c == "16")
            {
                int k;
                for (k = 12; k < 18; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 3; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[15].BackColor == SystemColors.Control)
                {
                    btn[15].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[15].BackColor = SystemColors.Control;
                }
            }

            if (c == "17")
            {
                int k;
                for (k = 12; k < 18; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 4; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[16].BackColor == SystemColors.Control)
                {
                    btn[16].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[16].BackColor = SystemColors.Control;
                }
            }

            if (c == "18")
            {
                int k;
                for (k = 12; k < 18; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 5; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[17].BackColor == SystemColors.Control)
                {
                    btn[17].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[17].BackColor = SystemColors.Control;
                }
            }


            if (c == "19")
            {
                int k;
                for (k = 18; k < 24; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 ; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[18].BackColor == SystemColors.Control)
                {
                    btn[18].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[18].BackColor = SystemColors.Control;
                }
            }

            if (c == "20")
            {
                int k;
                for (k = 18; k < 24; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 1; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[19].BackColor == SystemColors.Control)
                {
                    btn[19].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[19].BackColor = SystemColors.Control;
                }
            }

            if (c == "21")
            {
                int k;
                for (k = 18; k < 24; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 2; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[20].BackColor == SystemColors.Control)
                {
                    btn[20].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[20].BackColor = SystemColors.Control;
                }
                /*
                int k;
                for (k = 18; k < 24; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 2; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[20].BackColor == SystemColors.Control)
                {
                    btn[20].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[02].BackColor = SystemColors.Control;
                }*/


            }

            if (c == "22")
            {
                int k;
                for (k = 18; k < 24; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 3; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[21].BackColor == SystemColors.Control)
                {
                    btn[21].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[21].BackColor = SystemColors.Control;
                }
            }

            if (c == "23")
            {
                int k;
                for (k = 18; k < 24; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 4; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[22].BackColor == SystemColors.Control)
                {
                    btn[22].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[22].BackColor = SystemColors.Control;
                }
            }

            if (c == "24")
            {
                int k;
                for (k = 18; k < 24; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 5; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[23].BackColor == SystemColors.Control)
                {
                    btn[23].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[23].BackColor = SystemColors.Control;
                }
            }


            if (c == "25")
            {
                int k;
                for (k = 24; k < 30; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 ; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[24].BackColor == SystemColors.Control)
                {
                    btn[24].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[24].BackColor = SystemColors.Control;
                }
            }

            if (c == "26")
            {
                int k;
                for (k = 24; k < 30; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 1; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[25].BackColor == SystemColors.Control)
                {
                    btn[25].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[25].BackColor = SystemColors.Control;
                }
            }

            if (c == "27")
            {
                int k;
                for (k = 24; k < 30; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 2; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[26].BackColor == SystemColors.Control)
                {
                    btn[26].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[26].BackColor = SystemColors.Control;
                }
            }

            if (c == "28")
            {
                int k;
                for (k = 24; k < 30; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 3; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[27].BackColor == SystemColors.Control)
                {
                    btn[27].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[27].BackColor = SystemColors.Control;
                }
            }

            if (c == "29")
            {
                int k;
                for (k = 24; k < 30; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 4; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[28].BackColor == SystemColors.Control)
                {
                    btn[28].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[28].BackColor = SystemColors.Control;
                }
            }

            if (c == "30")
            {
                int k;
                for (k = 24; k < 30; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 5; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[29].BackColor == SystemColors.Control)
                {
                    btn[29].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[29].BackColor = SystemColors.Control;
                }
            }

            if (c == "31")
            {
                int k;
                for (k = 30; k < 36; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 ; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[30].BackColor == SystemColors.Control)
                {
                    btn[30].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[30].BackColor = SystemColors.Control;
                }
            }

            if (c == "32")
            {
                int k;
                for (k = 30; k < 36; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 1; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[31].BackColor == SystemColors.Control)
                {
                    btn[31].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[31].BackColor = SystemColors.Control;
                }
            }

            if (c == "33")
            {
                int k;
                for (k = 30; k < 36; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 2; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[32].BackColor == SystemColors.Control)
                {
                    btn[32].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[32].BackColor = SystemColors.Control;
                }
            }

            if (c == "34")
            {
                int k;
                for (k = 30; k < 36; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 3; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[33].BackColor == SystemColors.Control)
                {
                    btn[33].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[33].BackColor = SystemColors.Control;
                }
            }

            if (c == "35")
            {
                int k;
                for (k = 30; k < 36; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 4; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[34].BackColor == SystemColors.Control)
                {
                    btn[34].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[34].BackColor = SystemColors.Control;
                }
            }

            if (c == "36")
            {
                int k;
                for (k = 30; k < 36; k++)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                for (k = 0 + 5; k < 36; k = k + 6)
                {
                    if (btn[k].BackColor == SystemColors.Control)
                    {
                        btn[k].BackColor = Color.SkyBlue;
                    }
                    else
                    {
                        btn[k].BackColor = SystemColors.Control;
                    }
                }

                if (btn[35].BackColor == SystemColors.Control)
                {
                    btn[35].BackColor = Color.SkyBlue;
                }
                else
                {
                    btn[35].BackColor = SystemColors.Control;
                }
            }

        }


    }
}



